# odious - tl;dr remod ce w/ pasted code from multiple clients

## Credits

credits for everything related to the client can be found [here](https://github.com/notunixian/odious/blob/baa4cb1412b933fc37af08c6c74d1afa3fd1a7ae/ReModCE/ReMod.cs#L120) (some of these are joke credits, but most of them are there for actual reasons.)

**another thing**:

**this wouldn't be possible without** [Requi](https://github.com/RequiDev) and his projects [ReModCE](https://github.com/RequiDev/ReModCE), and the underlying framework [ReMod.Core](https://github.com/RequiDev/ReMod.Core) and you should thank him for creating such awesome things.


## you can download the latest build by going [to the releases page](https://github.com/notunixian/odious/releases/latest)
