# ReMod.Core
The core dependency of ReMod and ReModCE. This project contains several helper functions, wrappers and UI classes for VRChat, Unity and MelonLoader.
