﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReModCE.AvatarPostProcess
{
    internal class AntiCrashDynamicBonePostProcess
    {
        internal int nukedDynamicBones;

        internal int dynamicBoneCount;
    }
}
