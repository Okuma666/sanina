﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReModCE.AvatarPostProcess
{
    internal class AntiCrashDynamicBoneColliderPostProcess
    {
        internal int nukedDynamicBoneColliders;

        internal int dynamicBoneColiderCount;
    }
}
