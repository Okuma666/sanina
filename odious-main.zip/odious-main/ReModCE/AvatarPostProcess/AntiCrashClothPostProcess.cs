﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReModCE.AvatarPostProcess
{
    internal class AntiCrashClothPostProcess
    {
        internal int nukedCloths;

        internal int clothCount;

        internal int currentVertexCount;
    }
}
