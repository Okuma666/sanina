﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReModCE.AvatarPostProcess
{
    internal class AntiCrashMaterialPostProcess
    {
        internal int nukedMaterials;

        internal int materialCount;
    }
}
